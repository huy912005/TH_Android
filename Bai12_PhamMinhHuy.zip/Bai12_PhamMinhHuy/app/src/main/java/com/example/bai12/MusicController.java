package com.example.bai12;

import android.content.Context;
import android.widget.MediaController;

public class MusicController extends MediaController {
    public MusicController(Context c) {
        super(c);
    }
}
